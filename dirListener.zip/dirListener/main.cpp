#include <iostream>
#include "listener.h"

using namespace std;

int main() {
    listener("/home/cooperatio/");
    return 0;
}

